import React, { useEffect } from "react";
declare let $: any;

const CreateDashboards = () => {
  useEffect(() => {

    $.ig.RevealSdkSettings.setBaseUrl("http://localhost:56565/");
    var revealView = new $.ig.RevealView("#revealView");
    revealView.startInEditMode = true;

    //----------Adding the Rest Data source-------------
    revealView.onDataSourcesRequested = (callback: any) => {

        // Athena
        var athenaDS = new $.ig.RVAthenaDataSource();
        athenaDS.id = "athenaDSId";
        athenaDS.title = "Athena Data Source";
        athenaDS.subtitle = "";
        athenaDS.region = "us-east-1";
        athenaDS.database = "mydatabase";
        
        var athenaDSItem = new $.ig.RVAthenaDataSourceItem(athenaDS);
        athenaDSItem.id = "Invoices";
        athenaDSItem.title = "Invoices";
        athenaDSItem.subtitle = "";
        //athenaDSItem.table = "northwind invoices parquet";

        var athenaDSItem1 = new $.ig.RVAthenaDataSourceItem(athenaDS);
        athenaDSItem1.id = "Collisions";
        athenaDSItem1.title = "Collisions";
        athenaDSItem1.subtitle = "";
        //athenaDSItem.table = "northwind invoices parquet";

        callback(new $.ig.RevealDataSources([athenaDS], [athenaDSItem, athenaDSItem1], false));

    };
  }, []);

  return <div id="revealView" style={{ height: "100vh", width: "100%" }}></div>;
};

export default CreateDashboards;
