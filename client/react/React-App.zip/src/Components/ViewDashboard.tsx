import React, { useEffect, useState } from "react";
declare let $: any;


const apiURL = "http://localhost:56565/dashboards";
const ViewDashboard = (props: any) => {

  const [dashboardID, setDashboardId] = useState("Campaigns");
  const [dashboardNames, setDashboardNames] = useState([]);
  

  const xdashboardNames = [{"name":"Campaigns"},{"name":"Categories"},{"name":"Chicago Crime"},{"name":"Manufacturing"},{"name":"Marketing"},{"name":"New Dashboard"},{"name":"Orders Query"},{"name":"Project Management"},{"name":"Retail Inventory Management"},{"name":"Retail Performance"},{"name":"Sales"},{"name":"Social Media"},{"name":"Telecomm Customers"}];

  let changeDashboard = (e: any) => {
    setDashboardId(e.target.value);
  };

  useEffect(() => {
    
    fetch(apiURL, { method: "GET" }).then((res: any) => res.json())
      .then((dashboardNames:any)=>{
      setDashboardNames(dashboardNames);
      console.log(dashboardNames);
    });

    $.ig.RevealSdkSettings.setBaseUrl("http://localhost:56565/");
    var revealView = new $.ig.RevealView("#revealView");
    
    $.ig.RVDashboard.loadDashboard(dashboardID).then((dashboard: any) => {
      revealView.dashboard = dashboard;
    });
  }, [dashboardID]);

  return (
    <div className="container m-3">
      <div>
        <h3>Load Dashboard</h3>

        <select name="dashboards" id="dashboards-select"
        value={dashboardID}
        onChange={changeDashboard}>
        {dashboardNames.map((dashboard, index) => (
          <option key={index} value={dashboard}>
            {dashboard}
          </option>
        ))}
      </select>


      </div>
      <div id="revealView" style={{ height: "100vh", width: "100%" }}></div>
    </div>
  );
};

export default ViewDashboard;
